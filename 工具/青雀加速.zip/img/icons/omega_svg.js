var drawOmega = function (ctx, outerCircleColor, innerCircleColor) {
  ctx.clearRect(0,0,19,19)
  ctx.save();
  ctx.fillStyle = outerCircleColor;
  ctx.beginPath();

  ctx.moveTo(8.5,1.5);
  ctx.lineTo(15.5,7.5);
  ctx.lineTo(7.5,3.5);
  ctx.lineTo(8.5,1.5);
  ctx.fill('evenodd');

  ctx.moveTo(1.5,5.5);
  ctx.lineTo(15.5,6.0);
  ctx.lineTo(1.5,8.5);
  ctx.lineTo(1.5,5.5);
  ctx.fill('evenodd');

  ctx.moveTo(4.5,9.5);
  ctx.lineTo(15.5,6.5);
  ctx.lineTo(4.5,12.5);
  ctx.lineTo(4.5,9.5);
  ctx.fill('evenodd');

  ctx.moveTo(8.5,13.5);
  ctx.lineTo(15.5,7.0);
  ctx.lineTo(10.5,16.5);
  ctx.lineTo(8.5,13.5);
  ctx.fill('evenodd');

  //ctx.stroke();

  ctx.fill('evenodd');
  ctx.restore();
  ctx.save();
  ctx.fillStyle = outerCircleColor;

};
