
$(function(){

    getBrowserInfo();
		
});
	
    function getBrowserInfo()
    {
        var agent = navigator.userAgent.toLowerCase() ;

        var regStr_ie = /msie [\d.]+;/gi ;
        var regStr_ff = /maxthon\/[\d.]+/gi
        var regStr_chrome = /chrome\/[\d.]+/gi ;
        var regStr_saf = /qqbrowser\/[\d.]+/gi ;

        var body = $("body");
        //QQBrowser
        var browser_name = "";
        var browser_version = "";

        if(agent.indexOf("qqbrowser") > 0)
        {
            browser_name = "QQ浏览器";
            body.css("background-image","url('img/browser_tip/qqbrowser.jpg')");
        }
        if(agent.indexOf("lbbrowser") > 0)
        {
            browser_name = "猎豹浏览器";
            body.css("background-image","url('img/browser_tip/liebao.jpg')");
        }
		if (agent.indexOf("ubrowser") > 0)
        {
            browser_name = "UC浏览器";
            body.css("background-image","url('img/browser_tip/UC.jpg')");
        }
        if (agent.indexOf("bidubrowser") > 0)
        {
            browser_name = "百度浏览器";
            body.css("background-image","url('img/browser_tip/baidu.jpg')");
        }
        if (agent.indexOf("opr\/") > 0)
        {
            browser_name = "Opera浏览器";
            body.css("background-image","url('img/browser_tip/opera.jpg')");
        }

        //Chrome
        if(agent.indexOf("chrome") > 0)
        {
            browser_version=agent.match(regStr_chrome) ;
        }


    }