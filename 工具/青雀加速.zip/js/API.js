var COMMON_CONFIG_STRING = localStorage.getItem('COMMON_CONFIG_STRING')
console.log("COMMON_CONFIG_STRING:%s", COMMON_CONFIG_STRING);
var COMMON_CONFIG = $.parseJSON(COMMON_CONFIG_STRING)
var API_SERVER_FIRST = "https://www.94lala.top/index.php?maincfgver=1&channel=chrome_kljs&version=010314&";
var API_SERVER_DEFAULT = "https://www.mkszxh.com/index.php?maincfgver=1&channel=chrome_kljs&version=010314&";
var API_SERVER_BACKUP = "http://www.lala1.top/index.php?maincfgver=1&channel=chrome_kljs&version=010314&";
var API_SERVER_REG = "https://zhifu.luoyangjiazhuang.com/index.php?maincfgver=1&channel=chrome_kljs&version=010314&";

var API_SERVER = API_SERVER_FIRST;

var API_SERVER_RETRY_COUNT = 0;
var API_SERVER_BACKUP_COUNT = 0;
var IS_MAIN_FAILED = false;

var API = function(){
    var that = this;
    this.call = function(api_name,data,callback, isasync){
        
		if(api_name.indexOf("password_change_crxs")>1 || api_name.indexOf("doregister_crx")>1 || api_name.indexOf("forgot_password_step1_crx")>1 || api_name.indexOf("forgot_password_step2_crx")>1){
			API_SERVER = API_SERVER_REG;
		}
		
		$.ajax(API_SERVER + "" + api_name,{async:isasync,timeout:6000,type:"POST",dataType:"JSON",data:data,success:function(e){
            callback(e);
        },error:function(e){
            API_SERVER_RETRY_COUNT++;
            that.log(that.LOG_TYPE_ERROR,"API请求失败",API_SERVER + "-" + api_name);
            if (API_SERVER_RETRY_COUNT<=10)
            {
				if (API_SERVER == API_SERVER_FIRST)
				{
					API_SERVER = API_SERVER_DEFAULT;
				} else if (API_SERVER == API_SERVER_DEFAULT)
				{
					API_SERVER = API_SERVER_BACKUP;
				}
				else
				{
					API_SERVER = API_SERVER_FIRST;
				}

                window.setTimeout(function(){
                    that.call(api_name,data,callback, isasync);
                },100);
            }
            else
            {
                callback(e);
            }
        }})
    };
    this.get_var_list = function(type,callback){
        that.call("g=user&m=login&a=get_var_list2",{type:type},function(e){
            callback(e);
        }, true);
    };
    this.check_user_pass = function(username,password,hardware_sn,software_version,callback,is_kick)
    {
        that.call("g=user&m=login&a=dologin2",{username:username,password:password,hardware_sn:hardware_sn,soft_version:software_version,is_kick:is_kick},function(e){
            callback(e);
        }, true)
    };
    this.get_block_list = function(callback)
    {
        that.call("g=user&m=login&a=block_roles",{},function(e){
            callback(e);
        }, true);
    };
    this.do_reg = function(username,password,vcode,callback){
        that.call("g=user&m=register&a=doregister_crx",{email:username,password:password,vcode:vcode},function(e){
            callback(e);
        }, true)
    };
    this.do_fgpw_step1 = function(username,alino,code,callback){
        that.call("g=user&m=password&a=forgot_password_step1_crx",{email:username,trade_no:alino,vcode:code},function(e){
            callback(e);
        }, true)
    };
    this.do_fgpw = function(username,password,callback){
        that.call("g=user&m=register&a=password_change_crxs",{email:username,password:password},function(e){
            callback(e);
        }, true)
    };
    /*this.get_node_list = function(callback)
    {
        that.call("g=user&m=login&a=node_list",{},function(e){
            callback(e);
        });
    };*/
    this.get_node_list = function(callback)
    {
		
		var username_val = common.username;
		if(username_val == ""){
			username_val = common.user_data.username;
		}
        that.call("g=user&m=login&a=node_list",{username:username_val},function(e){
            callback(e);
        }, false);
    };
    this.check_update = function(callback){
        that.call("g=user&m=login&a=check_update",{client_version:common.version},function(e){
            callback(e);
        }, true);
    }
    this.USERNAME = '';
    this.LOG_TYPE_LOGIN = 1;
    this.LOG_TYPE_LOGOUT = 2;
    this.LOG_TYPE_ERROR = 4;
    this.LOG_TYPE_URL = 5;
    this.LOG_TYPE_CHECK_PASS = 6;
    this.LOG_TYPE_STATUS = 7;
    this.log = function(type,msg2,msg3){
        var hardware_sn = common.hard_key;
        var session_id = common.session_id;
        var txt = "msg:" + type  + "" ;
        var uid = common.username;

        chrome.system.storage.getInfo(function(info){
            common.get_chrome_storage("hard_key",function(e){
                txt += "|tx1:" + e ;
                txt += "|in2:" + common.version;
                if(type==that.LOG_TYPE_URL)
                {
                    txt += "|in3:" + msg3[0];
                    txt += "|tx4:" + msg3[1];
                    msg3="";
                    //msg2="";
                }
                if(type==that.LOG_TYPE_STATUS)
                {
                    txt += "|in3:" + msg3[0];
                    txt += "|tx4:" + msg3[1];
                    msg3="";
                    //msg2="";
                }
                if (type == that.LOG_TYPE_LOGIN)
                {
                    txt += "|tx3:" + getBrowserInfo();
                }
                if (msg2 != undefined && msg2!="")
                {
                    txt += "|tx2:" + msg2;
                }
                if (msg3 != undefined && msg3!="")
                {
                    txt += "|tx4:" + msg3;
                }

                if (uid != undefined && uid!="")
                {
                    txt += "|usr:" + uid;
                }
                if (session_id != undefined && session_id!="")
                {
                    txt += "|tx3:" + session_id;
                }
            });

        });

    };
};





function getBrowserInfo()
{
    var agent = navigator.userAgent.toLowerCase() ;

    var regStr_ie = /msie [\d.]+;/gi ;
    var regStr_ff = /maxthon\/[\d.]+/gi
    var regStr_chrome = /chrome\/[\d.]+/gi ;
    var regStr_saf = /qqbrowser\/[\d.]+/gi ;

    //QQBrowser
    var browser_name = "";
    var browser_version = "";
    if(agent.indexOf("qqbrowser") > 0)
    {
        browser_name = "QQ浏览器";
        browser_version=agent.match(regStr_saf) ;
    }
    if(agent.indexOf("maxthon") > 0)
    {
        browser_name = "遨游浏览器";
        browser_version=agent.match(regStr_ff) ;
    }
    if(agent.indexOf("lbbrowser") > 0)
    {
        browser_name = "猎豹浏览器";
    }
    if (agent.indexOf("bidubrowser"))
    {
        browser_name = "百度浏览器";
    }
    if (agent.indexOf("opr/"))
    {
        browser_name = "Opera浏览器";
    }
    if (agent.indexOf("ubrowser"))
    {
        browser_name = "UC浏览器";
    }
    //Chrome
    if(agent.indexOf("chrome") > 0)
    {
        browser_version=agent.match(regStr_chrome) ;
    }
    return(browser_name + ' ' + browser_version);


}