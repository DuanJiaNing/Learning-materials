/**
 * Created by Administrator on 2015/10/14.
 */
var Login = function(){
    var that = this;
    this.background = common.getBackground();
    this.is_regcheck = false;
    this.is_fgpwcheck = false;
    this.check_reg_input = function(){
        var username = $("#reg_username").val();
		username = $.trim(username);
        var password = $("#reg_password").val();
        var password2 = $("#reg_password2").val();
        var reg_vcode = $("#reg_vcode").val();
        var email = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/; 
        if(!email.test(username)){
            $("#reg_btn_text").show();
            $("#reg_ani").hide();
			
            $("#error_tip_reg_account").find("span").text("请填写email地址作为您的用户名！");
            $("#error_tip_reg_account").show();
            $("#error_tip_reg_password").hide();
			$("#reg_username").focus();
            return false;
        }
        if(!(password!=""  &&  password.length>=6))
        {
            $("#error_tip_reg_password").find("span").text("密码不可为空，必须大于6位！");
            $("#error_tip_reg_password").show();
            $("#error_tip_reg_account").hide();
            $("#reg_btn_text").show();
            $("#reg_ani").hide();
            return false;
        }
        if(password.indexOf("'") != -1 || username.indexOf("'") != -1 )
        {
            alert("密码或用户名中禁止使用单引号！");
            $("#reg_btn_text").show();
            $("#reg_ani").hide();
            return false;
        }
        if(password != password2)
        {
            $("#error_tip_reg_password").find("span").text("两次密码输入不一致");
            $("#error_tip_reg_password").show();
            $("#error_tip_reg_account").hide();
            $("#reg_btn_text").show();
            $("#reg_ani").hide();
            return false;
        }
		
		
        $("#error_tip_reg_password").hide();
				
        return true;
    };
	
    this.check_fgpw_input = function(){
        var username = $("#fgpw_username").val();
        var email = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/; 
        if(!email.test(username)){
            $("#fgpw_btn_text").show();
            $("#fgpw_ani").hide();
            $("#error_tip_fgpw_account").find("span").text("请填写注册时的正确邮箱！");
            $("#error_tip_fgpw_account").show();
			$("#fgpw_username").focus();
            return false;
        }
		
		
		var fgpw_alino = $("#fgpw_alino").val();
        if($.trim(fgpw_alino) == ""){
            $("#fgpw_btn_text").show();
            $("#fgpw_ani").hide();
            $("#error_tip_fgpw_alino").find("span").text("请填写支付宝历史订单号！");
            $("#error_tip_fgpw_alino").show();
			$("#fgpw_alino").focus();
            return false;
        }
		
		
        $("#error_tip_fgpw_account, #error_tip_fgpw_alino").hide();
        return true;
    };
	
	
	
    this.check_login_input = function(){

    };
	
    this.bind_events = function(){
		
		/*
		$('#reg_vcode_check').click(function(){
				
            var r = that.check_reg_input();
            if (r!=true)
            {
                return false;
            }
			var username = $("#reg_username").val();
					$('#reg_vcode_check').hide();
					$('#reg_vcode_check_tip').show();
					$('#reg_vcode_check_tip').text("正在发送...");
			api.send_reg_code(username,function(e){
		
				if(e.issend == true){

            		$("#error_tip_reg_account").hide();
					var intervalTime = null;
				
					var s = 300;
					$('#reg_vcode_check').hide();
					$('#reg_vcode_check_tip').show();
					intervalTime = setInterval(function(){
						if(s<=0){
							$('#reg_vcode_check').show();
							$('#reg_vcode_check_tip').hide();
							clearInterval(intervalTime);
						}else{
							$('#reg_vcode_check_tip').text('已发送('+s+')');
						}
						s--;
					}, 1000);
					$('#reg_username, #reg_password, #reg_password2').attr('readonly', 'readonly');
					
					$('#reg_vcode').keyup(function(){
						
						var val = $.trim($(this).val());
						if(val.length == 4 && !isNaN(val)){
							api.check_reg_code(val, function(e){
								if(e.is == true){
									clearInterval(intervalTime);
									$('#reg_vcode').attr('readonly', 'readonly');
									$('#error_tip_reg_vcode').hide();
									$('#reg_vcode_check_tip').text('验证码正确').css('color','#1CAA00');
									this.is_regcheck=true;
									is_reging = false;
							
								}else{
									$('#error_tip_reg_vcode').show().find("span").text("验证码错误");
									this.is_regcheck=false;
									is_reging = true;
								}
							});
						}
							
					});
					
				}else if(e.issend == 'exist'){
					$('#reg_vcode_check').show();
					$('#reg_vcode_check_tip').hide();
					$("#error_tip_reg_account").find("span").text("该E-mail已被注册！");
					
            		$("#error_tip_reg_account").show();
					return false;
				}else{
					alert("邮件发送失败，请刷新重新试试！");	
				}
				
				
				console.log(e);
			});
			
		});
		
		$('#fgpw_vcode_check').click(function(){
				
            var r = that.check_fgpw_input();
            if (r!=true)
            {
                return false;
            }
			var username = $("#fgpw_username").val();
					$('#fgpw_vcode_check').hide();
					$('#fgpw_vcode_check_tip').show();
					$('#fgpw_vcode_check_tip').text("正在发送...");
			api.send_fgpw_code(username,function(e){
				
				if(e.issend == true){

            		$("#error_tip_fgpw_account").hide();
					var intervalTime = null;
	
					var s = 300;
					$('#fgpw_vcode_check').hide();
					$('#fgpw_vcode_check_tip').show();
					intervalTime = setInterval(function(){
						if(s<=0){
							$('#fgpw_vcode_check').show();
							$('#fgpw_vcode_check_tip').hide();
							clearInterval(intervalTime);
						}else{
							$('#fgpw_vcode_check_tip').text('已发送('+s+')');
						}
						s--;
					}, 1000);
					$('#fgpw_username').attr('readonly', 'readonly');
					
					$('#fgpw_vcode').keyup(function(){
						
						var val = $.trim($(this).val());
						if(val.length == 4 && !isNaN(val)){
							api.check_reg_code(val, function(e){
								if(e.is == true){
									clearInterval(intervalTime);
									$('#fgpw_vcode').attr('readonly', 'readonly');
									$('#error_tip_fgpw_vcode').hide();
									$('#fgpw_vcode_check_tip').text('验证码正确').css('color','#1CAA00');
									this.is_fgpwcheck=true;
									$('#fgpw_step_2').show();
								}else{
									$('#error_tip_fgpw_vcode').show().find("span").text("验证码错误");
									this.is_fgpwcheck=false;
									$('#fgpw_step_2').hide();
								}
							});
						}
							
					});
					
				}else if(e.issend == 'exist'){
					$('#fgpw_vcode_check').show();
					$('#fgpw_vcode_check_tip').hide();
					$("#error_tip_fgpw_account").find("span").text("该E-mail不存在！");
            		$("#error_tip_fgpw_account").show();
					return false;
				}else{
					alert("邮件发送失败，请刷新重新试试！");	
				}
			});
			
		});
		*/
		
		$('.btn_forget_password').click(function(){
            $("#reg_box").hide();
            $("#login_box").hide();
            $("#forget_password_box").show();
            $(".tab").removeClass("active");
			return false;
		});
        $("#tab_login").click(function(e){
            $("#reg_box").hide();
            $("#login_box").show();
            $("#forget_password_box").hide();
            $(".tab").removeClass("active");
            $(this).addClass("active");
        });
        $("#tab_reg").click(function(e){
            $("#reg_box").show();
            $("#forget_password_box").hide();
            $("#login_box").hide();
            $(".tab").removeClass("active");
            $(this).addClass("active");
        });
        var is_kick = false;
        var is_logining = false;
        $("#btn_login").click(function(e){
            if (is_logining == true)
            {
                return false;
            }
            is_logining = true;
            $("#login_btn_text").hide();
            $("#login_ani").show();
            var username = $("#login_username").val();
            var password = $("#login_password").val();
            if (username=="" || password =="")
            {
				is_logining = false;
                $("#error_tip_login_account").find("span").html("用户名或密码不能为空");
                $("#error_tip_login_account").show();
                $("#login_btn_text").show();
                $("#login_ani").hide();
                return false;
            }
			window.USERNAMES=username;

			api.log(api.LOG_TYPE_LOGIN,"在登录界面尝试登录" , username + "/" + password);
            common.set_chrome_storage({username:username,password:password},function(){
				
		
                that.background.check_login(function(status,e){
                    is_logining = false;
                    if(status==true)
                    {
                    }
                    else
                    {
                        if (e.msg != undefined)
                        {
                            var html = "<a target='blank' href='options.html'>立即充值</a>";
                            e.msg = e.msg.replace("[err403]",html);
                            $("#error_tip_login_account").find("span").html(e.msg);
                            $("#error_tip_login_account").show();
                        }
                        else
                        {
                            $("#error_tip_login_account").find("span").text("用户名或密码错误！");
                            $("#error_tip_login_account").show();
                        }
                        $("#login_btn_text").show();
                        $("#login_ani").hide();
                    }
                },is_kick,true);
            });

            return false;
        });
        $("#btn_kick").click(function(){
            is_kick = true;
            $("#btn_login").click();
        });
        $("#reg_box input").blur(function(){
            that.check_reg_input();
        });
        $("#login_box input").blur(function(){
            that.check_login_input();
        });
		
		var is_fgpwing = false;
		var is_fgpw_step = false;
		$('#fgpw_btn').click(function(){

            if (is_fgpwing == true)
            {
                return false;
            }
			
            var r = that.check_fgpw_input();
            if (r!=true)
            {
				is_fgpwing = false;
                return false;
            }
			
            is_fgpwing = true;
			
        	var fgpw_alino = $("#fgpw_alino").val();
        	var fgpw_vcode = $("#fgpw_vcode").val();
			
			
			if(fgpw_vcode.length != 4)
			{
				$("#fgpw_vcode").focus();
				$("#error_tip_fgpw_vcode").find("span").text("请填写验证码");
				$("#error_tip_fgpw_vcode").show();
				$("#error_tip_fgpw_account").hide();
				$("#fgpw_btn_text").show();
				$("#fgpw_ani").hide();
				is_fgpwing = false;
				return false;
			}
			
				
			
            var username = $("#fgpw_username").val();
            var vcode = $("#fgpw_vcode").val();
			
            $("#fgpw_btn_text").hide();
            $("#fgpw_ani").show();
			$("#error_tip_fgpw_account").hide();
			$("#error_tip_fgpw_vcode").hide();
			
			
			if(!is_fgpw_step){
				
				
				
		api.do_fgpw_step1(username,fgpw_alino,vcode,function(e){
				
				is_fgpwing = false;
                if(e.message != "SUCCESS")
                {
                    alert(e.message);
					$("#fgpw_btn_text").show();
					$("#fgpw_ani").hide();
					$('#fgpw_step_2').hide();
					is_fgpw_step = false;
                }
                else
                {
                    
					$("#fgpw_btn_text").text('修改密码').show();
					$("#fgpw_ani, #fgpw_step_de").hide();
					$('#fgpw_step_2').show();
					$('#fgpw_username').attr('disabled', 'disabled');
					
					is_fgpw_step = true;
					/*$("#tab_login").click();
                    alert('密码修改成功，前往登录！');
					$('#login_username').val(username);*/
                }
		});
			}else{
		
			
            var username = $.trim($("#fgpw_username").val());
            var password = $.trim($("#fgpw_password").val());
            var password2 = $.trim($("#fgpw_password2").val());
			

			
        if(!(password!=""  &&  password.length>=6))
        {
            $("#error_tip_fgpw_password").find("span").text("密码不可为空，必须大于6位！");
            $("#error_tip_fgpw_password").show();
            $("#error_tip_fgpw_account").hide();
            $("#fgpw_btn_text").show();
            $("#fgpw_ani").hide();
			is_fgpwing = false;
            return false;
        }
        if(password.indexOf("'") != -1 || username.indexOf("'") != -1 )
        {
            alert("密码或用户名中禁止使用单引号！");
            $("#fgpw_btn_text").show();
            $("#fgpw_ani").hide();
			is_fgpwing = false;
            return false;
        }
        if(password != password2)
        {
            $("#error_tip_fgpw_password").find("span").text("两次密码输入不一致");
            $("#error_tip_fgpw_password").show();
            $("#error_tip_fgpw_account").hide();
            $("#fgpw_btn_text").show();
            $("#fgpw_ani").hide();
			is_fgpwing = false;
            return false;
        }
		
        $("#error_tip_fgpw_password").hide();
				
				
		api.do_fgpw(username,password,function(e){
				
				
				is_fgpwing = false;
                if(e==undefined || e.success == undefined || e.success !=true)
                {
                    alert(e.msg);
					$("#fgpw_btn_text").show();
					$("#fgpw_ani").hide();
                }
                else
                {
                    $("#tab_login").click();
                    alert('密码修改成功，前往登录！');
					$('#login_username').val(username);
					$("#fgpw_btn_text").show();
					$("#fgpw_ani").hide();
					is_fgpw_step=false;
                }
		});
			
		
		
			}
			
		
		return false;
			
			
			
			
		});
		
		var is_reging = false;
        $("#reg_btn").click(function(){
			
			
            if (is_reging == true)
            {
                return false;
            }
			

            var r = that.check_reg_input();
            if (r!=true)
            {
				is_reging = false;
                return false;
            }

            is_reging = true;
			
			
        	var reg_vcode = $("#reg_vcode").val();
			/*	
			if($('#reg_vcode_check_tip').text() != "验证码正确"){
				$("#error_tip_reg_vcode").find("span").text("请先进行邮箱验证");
				$("#error_tip_reg_vcode").show();
				$("#error_tip_reg_account,#error_tip_reg_password, #error_tip_reg_password2").hide();
				$("#reg_btn_text").show();
				$("#reg_ani").hide();
				return false;
			}*/
			if(reg_vcode.length != 4)
			{
				$("#error_tip_reg_vcode").find("span").text("请填写验证码");
				$("#error_tip_reg_vcode").show();
				$("#error_tip_reg_account,#error_tip_reg_password, #error_tip_reg_password2").hide();
				$("#reg_btn_text").show();
				$("#reg_ani").hide();
				is_reging = false;
				return false;
			}
			
			
            $("#reg_btn_text").hide();
            $("#reg_ani").show();
			
            var username = $("#reg_username").val();
            var password = $("#reg_password").val();
            var vcode = $.trim($("#reg_vcode").val());
            var password2 = $("#reg_password2").val();
			
            api.do_reg(username,password,vcode,function(e){
	
				is_reging = false;
                if(e==undefined || e.success == undefined || e.success !=true)
                {
                    api.log(api.LOG_TYPE_LOGIN,"注册失败" , username + "/" + password + "/" );
                    alert(e.msg);
                    $("#reg_btn_text").show();
                    $("#reg_ani").hide();
                }
                else
                {
                    api.log(api.LOG_TYPE_LOGIN,"注册成功" , username + "/" + password + "/" );
                    $("#tab_login").click();
                    alert('恭喜您注册成功！请登录后充值使用！');
					$('#login_username').val(username);
					$('#login_password').val(password);
					$('#btn_login').click();
                }
            });
			
			return false;
        });



    };







    var check_login_status = function(){
        var background = common.getBackground();
        var status = background.get_login_status();
        if (status==true)
        {
           // common.openOptions("options.html",true);
            common.openOptions("tip.html");
            window.setTimeout(function(){window.close();},200);
        }
    };
    check_login_status();
    window.setInterval(function(){
        check_login_status();
    },500);
};

$(document).ready(function(){
	var vimg = API_SERVER_REG+"&g=user&m=register&a=vcode";
	$('#verification_img, #verification_img2').attr('src', vimg).click(function(){
		$(this).attr('src', vimg+"&c="+Math.random());
	});
	
	
    var login = new Login();
    login.bind_events();
    common.get_all_chrome_storage(function(items){
        var username = items.username;
        var password = items.password;
        $("#login_username").val(username);
    });
    
    $("#version").text("V" + common.version_text);
	
	
   
}); 
